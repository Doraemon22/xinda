package com.xinda.cn.service;

import com.xinda.cn.model.xinda.Cart;
import com.xinda.cn.model.xinda.Product;

public interface CarService {

	int addcar(Product pro);
	  int insert(Cart record);

}
