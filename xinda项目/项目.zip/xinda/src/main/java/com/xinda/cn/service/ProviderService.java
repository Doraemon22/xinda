package com.xinda.cn.service;



public interface ProviderService {

	
}
