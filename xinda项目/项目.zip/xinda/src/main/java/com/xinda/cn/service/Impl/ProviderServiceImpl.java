package com.xinda.cn.service.Impl;



import org.springframework.stereotype.Service;


import com.xinda.cn.service.ProviderService;
@Service
public class ProviderServiceImpl implements ProviderService {

}
