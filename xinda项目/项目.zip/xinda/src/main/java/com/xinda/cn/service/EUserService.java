package com.xinda.cn.service;

import com.xinda.cn.model.xinda.EUser;

public interface EUserService {

	int set(EUser eUser);

	EUser setshow(String eid);

}
