$(".payment li").eq(1).on("click", function(){
    location.href="redirect?page=e-commerce_order" ;
})
