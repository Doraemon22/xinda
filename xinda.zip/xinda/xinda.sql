/*
SQLyog Ultimate v12.08 (64 bit)
MySQL - 8.0.16 : Database - xinda
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`xinda` /*!40100 DEFAULT CHARACTER SET utf8 */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `xinda`;

/*Table structure for table `business_order` */

DROP TABLE IF EXISTS `business_order`;

CREATE TABLE `business_order` (
  `ID` varchar(32) NOT NULL COMMENT '主键',
  `BUSINESS_NO` varchar(32) DEFAULT NULL COMMENT '业务订单编号',
  `PRODUCT_ID` varchar(32) DEFAULT NULL COMMENT '平台产品id',
  `ORDER_INFO` varchar(256) DEFAULT NULL COMMENT '订单内容',
  `STATUS` int(22) NOT NULL COMMENT '状态(1.未支付，2.已支付，3.已取消)',
  `UNIT_PRICE` int(22) DEFAULT NULL COMMENT '单价',
  `BUY_NUM` int(22) DEFAULT NULL COMMENT '购买数量',
  `TOTAL_PRICE` int(22) DEFAULT NULL COMMENT '总费用',
  `PAY_TYPE` int(22) DEFAULT NULL COMMENT '支付方式',
  `E_ID` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '电商用户id',
  `CREATE_TIME` date DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`ID`,`STATUS`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `business_order` */

insert  into `business_order`(`ID`,`BUSINESS_NO`,`PRODUCT_ID`,`ORDER_INFO`,`STATUS`,`UNIT_PRICE`,`BUY_NUM`,`TOTAL_PRICE`,`PAY_TYPE`,`E_ID`,`CREATE_TIME`) values ('1','1','1','1',1,1,1,1,1,'1','2019-11-01'),('10','10','10','10',10,10,10,10,10,'10','2019-11-10'),('11','11','11','11',11,11,11,11,11,'11','2019-11-11'),('12','12','12','12',12,12,12,12,12,'12','2019-11-12'),('2','2','2','2',2,2,2,2,2,'2','2019-11-02'),('20','20','56','4564',564,564,56,456,46,'46','2019-11-21'),('3','3','3','3',3,3,3,3,3,'3','2019-11-03'),('312','132123','3','3',213,132,123,1,3,'132','2019-11-28'),('4','4','4','4',4,4,4,4,4,'4','2019-11-04'),('456','465','46','46',64,45,7,8,64,'34','2019-11-22'),('5','5','5','5',5,5,5,5,5,'5','2019-11-05'),('6','6','6','6',6,6,6,6,6,'6','2019-11-06'),('635','64','6','243',453,453,435,43,453,'43','2019-11-29'),('7','7','7','7',7,7,7,7,7,'7','2019-11-07'),('8','8','8','8',8,8,8,8,8,'8','2019-11-08'),('9','9','9','9',9,9,9,9,9,'9','2019-11-09');

/*Table structure for table `cart` */

DROP TABLE IF EXISTS `cart`;

CREATE TABLE `cart` (
  `ID` varchar(32) CHARACTER SET utf8 COLLATE utf8_sinhala_ci NOT NULL COMMENT '主键',
  `E_ID` varchar(32) CHARACTER SET utf8 COLLATE utf8_sinhala_ci DEFAULT NULL COMMENT '电商用户id',
  `PRODUCT_ID` varchar(32) CHARACTER SET utf8 COLLATE utf8_sinhala_ci DEFAULT NULL COMMENT '平台产品id',
  `SERVICE_ID` varchar(32) CHARACTER SET utf8 COLLATE utf8_sinhala_ci DEFAULT NULL COMMENT '服务产品id',
  `SERVICE_NAME` varchar(64) CHARACTER SET utf8 COLLATE utf8_sinhala_ci DEFAULT NULL COMMENT '服务名称',
  `SERVICE_INFO` varchar(1024) CHARACTER SET utf8 COLLATE utf8_sinhala_ci DEFAULT NULL COMMENT '服务内容',
  `TOTAL_PRICE` int(22) DEFAULT NULL COMMENT '总价    金额',
  `SERVICE_REQUESR` varchar(1024) CHARACTER SET utf8 COLLATE utf8_sinhala_ci DEFAULT NULL COMMENT '服务需求',
  `PROVIDER_ID` varchar(32) CHARACTER SET utf8 COLLATE utf8_sinhala_ci DEFAULT NULL COMMENT '服务商id',
  `UNIT` varchar(16) CHARACTER SET utf8 COLLATE utf8_sinhala_ci DEFAULT NULL COMMENT '单位*',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_sinhala_ci;

/*Data for the table `cart` */

/*Table structure for table `e_user` */

DROP TABLE IF EXISTS `e_user`;

CREATE TABLE `e_user` (
  `ID` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '主键',
  `LOGIN_ID` varchar(64) CHARACTER SET utf8 COLLATE utf8_sinhala_ci NOT NULL COMMENT '登录帐号',
  `PASSWORD` varchar(128) CHARACTER SET utf8 COLLATE utf8_sinhala_ci NOT NULL COMMENT '密码',
  `NAME` varchar(16) CHARACTER SET utf8 COLLATE utf8_sinhala_ci DEFAULT NULL COMMENT '姓名',
  `Sex` int(22) DEFAULT NULL COMMENT '性别(1、男,2、女)',
  `CELLPHONE` varchar(16) CHARACTER SET utf8 COLLATE utf8_sinhala_ci NOT NULL COMMENT '手机号',
  `HEAD_IMG` varchar(64) CHARACTER SET utf8 COLLATE utf8_sinhala_ci DEFAULT NULL COMMENT '头像',
  `REGISTER_TIME` date DEFAULT NULL COMMENT '注册时间',
  `EMAIL` varchar(128) CHARACTER SET utf8 COLLATE utf8_sinhala_ci DEFAULT NULL COMMENT '邮箱',
  `STATUS` int(22) DEFAULT NULL COMMENT '状态(1、正常,2、停用)',
  `LAST_LOGIN_TIME` date DEFAULT NULL COMMENT '最后登录时间',
  `REGION_ID` varchar(32) CHARACTER SET utf8 COLLATE utf8_sinhala_ci DEFAULT NULL COMMENT '地区号*',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `e_user` */

insert  into `e_user`(`ID`,`LOGIN_ID`,`PASSWORD`,`NAME`,`Sex`,`CELLPHONE`,`HEAD_IMG`,`REGISTER_TIME`,`EMAIL`,`STATUS`,`LAST_LOGIN_TIME`,`REGION_ID`) values ('1','1','123','aaa',1,'12345678901',NULL,NULL,NULL,NULL,NULL,NULL),('2','2','123','bbb',2,'12345667889',NULL,NULL,NULL,NULL,NULL,NULL),('3','3','123','ccc',1,'12345678945',NULL,NULL,NULL,NULL,NULL,NULL),('4','4','123','ddd',1,'12345678978',NULL,NULL,NULL,NULL,NULL,NULL),('5','5','123','eee',2,'78946521231',NULL,NULL,NULL,NULL,NULL,NULL),('6','6','123','fff',2,'45678912345',NULL,NULL,NULL,NULL,NULL,NULL),('7','7','123','ggg',1,'78945665422',NULL,NULL,NULL,NULL,NULL,NULL);

/*Table structure for table `product` */

DROP TABLE IF EXISTS `product`;

CREATE TABLE `product` (
  `ID` varchar(32) CHARACTER SET utf8 COLLATE utf8_sinhala_ci NOT NULL COMMENT '主键',
  `NAME` varchar(64) CHARACTER SET utf8 COLLATE utf8_sinhala_ci DEFAULT NULL COMMENT '产品名称',
  `CODE` int(22) DEFAULT NULL COMMENT '服务商编号',
  `IMG` blob COMMENT '图片',
  `INFO` varchar(256) CHARACTER SET utf8 COLLATE utf8_sinhala_ci DEFAULT NULL COMMENT '产品简介',
  `SHOW_ORDER` int(22) DEFAULT NULL COMMENT '排序',
  `STYLE_ID` varchar(32) CHARACTER SET utf8 COLLATE utf8_sinhala_ci DEFAULT NULL COMMENT '产品类型id',
  `TYPE_ID` varchar(32) CHARACTER SET utf8 COLLATE utf8_sinhala_ci DEFAULT NULL COMMENT '产品分类id',
  `MAPKET_PRICE` int(22) DEFAULT NULL COMMENT '市场价格',
  `UNIT` varchar(8) CHARACTER SET utf8 COLLATE utf8_sinhala_ci DEFAULT NULL COMMENT '单位',
  `STORE_NUM` int(22) DEFAULT NULL COMMENT '库存量',
  `SALE_NUM` int(22) DEFAULT NULL COMMENT '已售数量',
  `STATUS` int(22) DEFAULT NULL COMMENT '状态(1、在线,2、下线)',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_sinhala_ci;

/*Data for the table `product` */

insert  into `product`(`ID`,`NAME`,`CODE`,`IMG`,`INFO`,`SHOW_ORDER`,`STYLE_ID`,`TYPE_ID`,`MAPKET_PRICE`,`UNIT`,`STORE_NUM`,`SALE_NUM`,`STATUS`) values ('1','小熊',1,'/images/godness.jpg','这是一只会讲话的熊熊',NULL,NULL,NULL,11,NULL,NULL,NULL,NULL),('10','龙',3,NULL,'我是一条龙',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('2','小熊',1,NULL,'这是一只会跳舞的熊熊',NULL,NULL,NULL,69,NULL,NULL,NULL,NULL),('3','小熊维尼',1,NULL,'这是一只神奇的小熊',NULL,NULL,NULL,120,NULL,NULL,NULL,NULL),('4','小熊1',2,NULL,'xxxxx',NULL,NULL,NULL,123,NULL,NULL,NULL,NULL),('5','小熊2',2,NULL,'我是一只开心熊',NULL,NULL,NULL,99,NULL,NULL,NULL,NULL),('6','小熊6',2,NULL,'5555',NULL,NULL,NULL,55,NULL,NULL,NULL,NULL),('7','小熊7',3,NULL,'777',NULL,NULL,NULL,77,NULL,NULL,NULL,NULL),('8','狗狗',3,NULL,'这是一只机器狗',NULL,NULL,NULL,11,NULL,NULL,NULL,NULL),('9','老虎',3,NULL,'这是一只会说人话的老虎',NULL,NULL,NULL,100,NULL,NULL,NULL,NULL);

/*Table structure for table `provider` */

DROP TABLE IF EXISTS `provider`;

CREATE TABLE `provider` (
  `ID` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '主键',
  `TYPE` int(22) DEFAULT NULL COMMENT '1、个人，2、企业',
  `pcode` int(22) DEFAULT NULL COMMENT '产品在电商编号*',
  `sname` varchar(16) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '名称',
  `PROVIDER_INFO` varchar(1024) DEFAULT NULL COMMENT '服务说明',
  `CELLPHONE` varchar(16) DEFAULT NULL COMMENT '手机号',
  `LOGIN_ID` varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '登录帐号',
  `PASSWORD` varchar(128) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '密码',
  `PROVIDER_IMG` blob COMMENT '服务商头像',
  `REGION_ID` varchar(32) DEFAULT NULL COMMENT '地区',
  `REGISTER_TIME` date DEFAULT NULL COMMENT '注册时间',
  `STATUS` int(22) DEFAULT NULL COMMENT '状态（1、正常，2、停用）',
  `AUTH_FILE` varchar(64) DEFAULT NULL COMMENT '认证文件',
  `WEIXIN` varchar(16) DEFAULT NULL COMMENT '微信号',
  `QQ` varchar(16) DEFAULT NULL COMMENT 'qq号',
  `WORK_TIME` varchar(64) DEFAULT NULL COMMENT '工作时间',
  `EMALL` varchar(64) DEFAULT NULL COMMENT '邮箱',
  `RECOMMEND` int(22) DEFAULT NULL COMMENT '是否推荐服务商',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `provider` */

insert  into `provider`(`ID`,`TYPE`,`pcode`,`sname`,`PROVIDER_INFO`,`CELLPHONE`,`LOGIN_ID`,`PASSWORD`,`PROVIDER_IMG`,`REGION_ID`,`REGISTER_TIME`,`STATUS`,`AUTH_FILE`,`WEIXIN`,`QQ`,`WORK_TIME`,`EMALL`,`RECOMMEND`) values ('1',NULL,1,'熊猫有限公司','玩具公司',NULL,'1','123456',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('2',NULL,NULL,'tf有限公司','xxxxxxxxxxxx公司',NULL,'2','123456',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('3',NULL,NULL,'动物有限公司','动物玩具公司',NULL,'3','123456',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);

/*Table structure for table `provider_img` */

DROP TABLE IF EXISTS `provider_img`;

CREATE TABLE `provider_img` (
  `ID` varchar(32) NOT NULL,
  `TYPE` int(22) DEFAULT NULL COMMENT '1、大图，2、企业客户图片，3、营业执照，4、税务登记，5、人力资源服务证，6、组织机构代码证',
  `IMG_PATH` blob COMMENT '图片地址',
  `PROVIDER_ID` varchar(32) DEFAULT NULL COMMENT '服务说明',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `provider_img` */

/*Table structure for table `provider_product` */

DROP TABLE IF EXISTS `provider_product`;

CREATE TABLE `provider_product` (
  `ID` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '服务商产品  表',
  `PROVIDER_ID` varchar(32) DEFAULT NULL COMMENT '服务商id',
  `PRODUCT_ID` varchar(32) DEFAULT NULL COMMENT '平台产品id',
  `SERVICE_NAME` varchar(16) DEFAULT NULL COMMENT '服务名称',
  `SERVICE_INFO` varchar(128) DEFAULT NULL COMMENT '服务简介',
  `SERVICE_IMG` blob COMMENT '服务产品图片',
  `SERVICE_CONTENT` text CHARACTER SET utf8 COLLATE utf8_general_ci COMMENT '服务内容',
  `REGION_ID` varchar(32) DEFAULT NULL COMMENT '地区',
  `PRICE` int(22) DEFAULT NULL COMMENT '价格',
  `UNIT` varchar(16) DEFAULT NULL COMMENT '单位',
  `STATUS` int(22) DEFAULT NULL COMMENT '状态（1、在线，2、下线）',
  `RECOMMEND` int(22) DEFAULT NULL COMMENT '是否推荐产品',
  `HIGH QUALITY` int(22) DEFAULT NULL COMMENT '是否创业必备*',
  `CREATE_TIME` date DEFAULT NULL COMMENT '创建时间',
  `STAR` int(22) DEFAULT NULL COMMENT '是否明星产品*',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `provider_product` */

/*Table structure for table `region` */

DROP TABLE IF EXISTS `region`;

CREATE TABLE `region` (
  `ID` varchar(32) NOT NULL COMMENT '主键',
  `NAME` varchar(64) DEFAULT NULL COMMENT '地区名称',
  `LEVEL` int(22) DEFAULT NULL COMMENT '地区级别',
  `PARENT_ID` varchar(32) DEFAULT NULL COMMENT '上级地区id',
  `POST_CODE` varchar(16) DEFAULT NULL COMMENT '邮编',
  `REGION_CODE` varchar(16) DEFAULT NULL COMMENT '地区编号',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `region` */

/*Table structure for table `service_judge` */

DROP TABLE IF EXISTS `service_judge`;

CREATE TABLE `service_judge` (
  `ID` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '主键',
  `CONTENT` varchar(1024) DEFAULT NULL COMMENT '评价内容',
  `JUDGE_TIME` date DEFAULT NULL COMMENT '评价时间',
  `TAGS` varchar(1024) DEFAULT NULL COMMENT '评价标签',
  `E_ID` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '电商用户id',
  `TYPE` int(22) DEFAULT NULL COMMENT '评价类型（1.好评2.中评3.差评）',
  `STATUS` int(22) DEFAULT NULL COMMENT '评价状态（1.未评价2.已评价）',
  `ORDER_ID` varchar(32) DEFAULT NULL COMMENT '业务订单id',
  `SERVICE_ID` varchar(32) DEFAULT NULL COMMENT '服务订单id',
  `PROVIDER_ID` varchar(32) DEFAULT NULL COMMENT '服务商id',
  `SCORE` int(22) DEFAULT NULL COMMENT '评分',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `service_judge` */

/*Table structure for table `service_order` */

DROP TABLE IF EXISTS `service_order`;

CREATE TABLE `service_order` (
  `ID` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '主键  服务订单',
  `SERVICE_NO` varchar(32) DEFAULT NULL COMMENT '订单服务编号',
  `ORDER_ID` varchar(32) DEFAULT NULL COMMENT '业务员订单',
  `E_ID` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '电商用户id',
  `PRODUCT_ID` varchar(32) DEFAULT NULL COMMENT '平台产品id',
  `SERVICE_ID` varchar(32) DEFAULT NULL COMMENT '服务商产品id',
  `SERVICE_NAME` varchar(64) DEFAULT NULL COMMENT '服务名称',
  `SERVICE_INFO` varchar(1024) DEFAULT NULL COMMENT '服务内容',
  `UNIT_PRICE` int(22) DEFAULT NULL COMMENT '单价',
  `BUY_NUM` int(22) DEFAULT NULL COMMENT '购买数量',
  `TOTAL_PRICE` int(22) DEFAULT NULL COMMENT '总费用',
  `STATUS` int(22) DEFAULT NULL COMMENT '1.未支付2.分配服务商3.服务商服务中4.已完成5.已取消',
  `CREATE_TIME` date DEFAULT NULL COMMENT '创建时间',
  `SERVICE_REQUEST` varchar(1024) DEFAULT NULL COMMENT '服务请求',
  `PROVIDER_ID` varchar(32) DEFAULT NULL COMMENT '服务商id',
  `UNIT` varchar(16) DEFAULT NULL COMMENT '单位',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `service_order` */

insert  into `service_order`(`ID`,`SERVICE_NO`,`ORDER_ID`,`E_ID`,`PRODUCT_ID`,`SERVICE_ID`,`SERVICE_NAME`,`SERVICE_INFO`,`UNIT_PRICE`,`BUY_NUM`,`TOTAL_PRICE`,`STATUS`,`CREATE_TIME`,`SERVICE_REQUEST`,`PROVIDER_ID`,`UNIT`) values ('1','1','1','1','1','1','abc',NULL,NULL,1,123,NULL,'2019-11-07',NULL,NULL,NULL),('2','2','2','2','2','2','def',NULL,NULL,2,240,NULL,'2019-11-07',NULL,NULL,NULL),('3','3','3','3','3','3','acd',NULL,NULL,1,510,NULL,'2019-11-07',NULL,NULL,NULL),('4','4','4','4','4','4','qwe',NULL,NULL,3,900,NULL,'2019-11-07',NULL,NULL,NULL),('5','5','5','5','5','5','tte',NULL,NULL,2,980,NULL,'2019-11-07',NULL,NULL,NULL),('6','6','6','6','6','6','poy',NULL,NULL,2,540,NULL,'2019-11-07',NULL,NULL,NULL),('7','7','7','7','7','7','asd',NULL,NULL,1,150,NULL,'2019-11-07',NULL,NULL,NULL);

/*Table structure for table `sysuser` */

DROP TABLE IF EXISTS `sysuser`;

CREATE TABLE `sysuser` (
  `ID` varchar(32) NOT NULL COMMENT '主键',
  `USER_NAME` varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '名字',
  `HEAD_IMG` blob COMMENT '头像',
  `LOGIN_ID` varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '登录名',
  `PASSWORD` varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '密码',
  `EMAIL` varchar(256) DEFAULT NULL COMMENT '邮箱',
  `CELLPHONE` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '手机号',
  `STATUS` int(22) DEFAULT NULL COMMENT '状态（1：有效2：无效）',
  `REGISTER_TIME` date DEFAULT NULL COMMENT '注册时间',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `sysuser` */

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
