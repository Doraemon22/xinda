package com.xinda.cn.controller.xinda;

import org.springframework.stereotype.Controller;

@Controller
public class EMyOrder {

}
