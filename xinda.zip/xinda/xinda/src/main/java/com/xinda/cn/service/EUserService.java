package com.xinda.cn.service;

public interface EUserService {

}
