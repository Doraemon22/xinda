package com.xinda.cn.service.Impl;

public class EUserServiceImpl {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
