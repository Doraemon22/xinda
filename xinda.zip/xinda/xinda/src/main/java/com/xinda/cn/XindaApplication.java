package com.xinda.cn;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class XindaApplication {

	public static void main(String[] args) {
		SpringApplication.run(XindaApplication.class, args);
	}

}
