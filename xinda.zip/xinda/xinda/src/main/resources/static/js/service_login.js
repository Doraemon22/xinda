$(".login-btn").on("click", function(){
    location.href="findSproByName"
})