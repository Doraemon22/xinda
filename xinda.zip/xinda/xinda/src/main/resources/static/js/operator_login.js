$(".login-btn").on("click", function(){
    location.href="redirect?page=operator_product"
})