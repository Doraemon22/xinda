//此页本无东东，为了跳转加了以下内容

$(".login-btn").on("click", function(){
    location.href="findProByname"//ePageProlist    e-commerce_product.html    redirect?page=e-commerce_product
    	//findProByname    ePageProlist都可以实现
})
